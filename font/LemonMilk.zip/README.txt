Lemon/Milk.otf ver 3.0 (donationware)

In this version, Lemon/Milk comes with the family; regular, regular-italic, bold, bold-italic, light, light-italic.
Moreover, I have modified some letters such as "B", "Q", and "S" and some issues have been fixed. 

----------IMPORTANT NOTE:----------
If you have questions regarding font usage, especially for commercial use,
kindly check my F.A.Q page at: http://blog.marsnev.com/p/faq.html

if you cannot get the answers there,
kindly contact me at:
email address: marsnev@marsnev.com

Stay tuned with the update, and other affordable great fonts:
http://www.marsnev.com
facebook.com/marsneveneksk
twitter.com/MARSNEV
instagram.com/MARSNEV

If you want to donate,
my PayPal address: marsnev@marsnev.com
Every donation is greatly appreciated.

Thanks for being supportive,
MARSNEV
Jakarta, Indonesia